#!/bin/bash

javac -d bin -sourcepath src src/Controleur.java
java -cp bin Controleur