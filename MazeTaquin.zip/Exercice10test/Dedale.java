import java.util.Scanner;
import java.io.FileReader;
import java.io.FileInputStream;
import iut.algo.Decomposeur;

public class Dedale 
{
	// CONSTANTES
	private final static int TAILLE_TAB_PIECE =  5;

	private final int NIV_MIN = 1;
	private final int NIV_MAX = 20;

	// VARIABLES
	private Piece[][] tabPiece;
	private Piece     pieceHeros;
	private char      orientationHeros;
	private int       cptMvt, cptCase;
	private int       niveau;
	private boolean   aCle;
	private boolean   estCoffreOuvert;

	// CONSTRUCTEUR
	public Dedale()
	{
		this.niveau = NIV_MIN;

		this.initNiveau();
	}

	// INIT

	private void initNiveau()
	{
		this.cptMvt           = this.cptCase = 0 ;
		this.orientationHeros = 's' ;

		this.tabPiece         = Dedale.initPiece(this.niveau);
		this.pieceHeros       = this.initHeros() ;

		this.aCle             = false ;
		this.estCoffreOuvert  = true ;

		if(this.estNiveauCoffre())
		{
			this.estCoffreOuvert = false ;
		}
	}

	private boolean estNiveauCoffre()
	{
		for (int i = 0; i < this.tabPiece.length; i++) 
		{
			for (int j = 0; j < this.tabPiece[0].length; j++) 
			{
				if (this.tabPiece[i][j] != null && this.tabPiece[i][j].getCoffre()) 
				{
					return true;
				}
			}
		}
		return false;
	}

	private static Piece[][] initPiece(int niveau) 
	{
		int[][] tabPieceValeurs;
		Piece[][] tabPiece;
		int cpt;

		tabPieceValeurs = Dedale.lireNiveau(niveau);

		tabPiece = new Piece[Dedale.TAILLE_TAB_PIECE][Dedale.TAILLE_TAB_PIECE];
		cpt = 0;

		for (int i = 0; i < tabPiece.length; i++) 
		{
			for (int j = 0; j < tabPiece[0].length; j++) 
			{
				if (tabPieceValeurs[i][j] >= 0) 
				{
					tabPiece[i][j] = new Piece(tabPieceValeurs[i][j],
					                           "" + (char) ('A' + cpt));
				} 
				else 
				{
					tabPiece[i][j] = null;
				}
				cpt++;
			}
		}

		return tabPiece;
	}


	private static int[][] lireNiveau(int niveau) 
	{
		int[][] tabPieceValeurs;

		tabPieceValeurs = null;

		try 
		{
			Scanner sc = new Scanner(new FileReader("./niveaux/niveau_" 
			                                        + String.format("%02d", niveau) + ".data"));

			sc.nextLine();
			tabPieceValeurs = new int[Dedale.TAILLE_TAB_PIECE][Dedale.TAILLE_TAB_PIECE];
			
			for (int lig = 0; lig < tabPieceValeurs.length; lig++)
			{
				Decomposeur dc = new Decomposeur(sc.nextLine());
				for (int col = 0; col < tabPieceValeurs[0].length; col++) 
				{
					tabPieceValeurs[lig][col] = dc.getInt(col);
				}
			}

			sc.close();
		} 
		catch (Exception e) { e.printStackTrace(); }

		return tabPieceValeurs;
	}


	private Piece initHeros()
	{
		for (int lig = 0; lig < this.tabPiece.length; lig++)
		{
			for (int col = 0; col < this.tabPiece[lig].length; col++)
			{
				if (this.getPiece(lig, col) != null && this.tabPiece[lig][col].getDepart())
				{
					return this.tabPiece[lig][col];
				}
			}
		}
		return null;
	}

	// METHODES

	private Piece getPieceAdj(int lig, int col, char dir) 
	{

		Piece res = null;

		// Nord
		if (lig > 0 && dir == 'N') 
		{
			res = this.tabPiece[lig - 1][col];
		}

		// Ouest
		if (col > 0 && dir == 'O') 
		{
			res = this.tabPiece[lig][col - 1];
		}

		// Sud
		if (lig < this.tabPiece.length - 1 && dir == 'S') 
		{
			res = this.tabPiece[lig + 1][col];
		}

		// Est
		if (col < this.tabPiece[0].length - 1 && dir == 'E') 
		{
			res = this.tabPiece[lig][col + 1];
		}

		return res;
	}

	public int getNbLigne() 
	{
		return this.tabPiece.length;
	}

	public int getNbColonne() 
	{
		return this.tabPiece[0].length;
	}

	public Piece getPiece(int lig, int col) 
	{
		return this.tabPiece[lig][col];
	}

	public int getCptCase() 
	{
		return this.cptCase;
	}

	public int getCptMvt() 
	{
		return this.cptMvt;
	}

	public int getNiveau() 
	{
		return this.niveau;
	}

	public boolean getACle()
	{
		return this.aCle ;
	}

	public boolean getEstCoffreOuvert()
	{
		return this.estCoffreOuvert ;
	}

	public String getDifficulte() 
	{
		String r = "";
		try 
		{
			Scanner sc = new Scanner(   new FileInputStream("./niveaux/niveau_" 
			                          + String.format("%02d", niveau) 
									  + ".data"), "UTF8");

			
			Decomposeur dc = new Decomposeur(sc.nextLine());
			r = dc.getString(0);
			

			sc.close();
		} 
		catch (Exception e) { e.printStackTrace(); }
		
		return r ;

	}

	public char getSymboleHeros(int lig, int col) 
	{
		if (lig == rechercherPosition(this.pieceHeros).getLig()
		&&  col == rechercherPosition(this.pieceHeros).getCol()) 
		{
			return this.orientationHeros;
		}
		return ' ';
	}

	public boolean estValide() 
	{
		boolean estOK = true;
		for (int i = 0; i < this.getNbLigne(); i++) 
		{
			for (int j = 0; j < this.getNbColonne(); j++) 
			{
				if (this.getPieceAdj(i, j, 'N') != null) 
				{
					if (this.getPiece(i, j).getOuverture('N') != this.getPieceAdj(i, j, 'N').getOuverture('S')) 
					{
						estOK = false;
					}
				}

				if (this.getPieceAdj(i, j, 'O') != null) 
				{
					if (this.getPiece(i, j).getOuverture('O') != this.getPieceAdj(i, j, 'O').getOuverture('E')) 
					{
						estOK = false;
					}
				}

				if (this.getPieceAdj(i, j, 'S') != null) 
				{
					if (this.getPiece(i, j).getOuverture('S') != this.getPieceAdj(i, j, 'S').getOuverture('N')) 
					{
						estOK = false;
					}
				}

				if (this.getPieceAdj(i, j, 'E') != null) 
				{
					if (this.getPiece(i, j).getOuverture('E') != this.getPieceAdj(i, j, 'E').getOuverture('O')) 
					{
						estOK = false;
					}
				}

			}
		}

		return estOK;
	}

	public boolean niveaux(char bouton) 
	{
		switch (bouton) 
		{
			case 'S':
				if (this.pieceHeros.getArrivee() && this.niveau < this.NIV_MAX && this.estCoffreOuvert)
				{
					this.niveau++;
					this.initNiveau();
					return true ;
				}
				return false ;
			case 'P':
				if (this.niveau > this.NIV_MIN )
				{
					this.niveau--;
					this.initNiveau();
					return true ;
				}
				return false ;
			case 'R':
				this.initNiveau();
				return true ;
			default:
				return false ;
		}


	}


	public String validite() 
	{
		boolean estOK = true;
		String result = "";
		for (int i = 0; i < this.getNbLigne(); i++) 
		{
			for (int j = 0; j < this.getNbColonne(); j++) 
			{
				result += "Piece[" + String.format("%2s", i)
						+ "][" + String.format("%2s", j)
						+ "] " + String.format("%2s", this.getPiece(i, j).getValOuvertures());

				if (this.getPieceAdj(i, j, 'N') != null) 
				{
					if (this.getPiece(i, j).getOuverture('N') != this.getPieceAdj(i, j, 'N').getOuverture('S')) 
					{
						estOK = false;
						result += "\n\t pb avec pièce située au Nord";
					}
				}

				if (this.getPieceAdj(i, j, 'O') != null) 
				{
					if (this.getPiece(i, j).getOuverture('O') != this.getPieceAdj(i, j, 'O').getOuverture('E')) 
					{
						estOK = false;
						result += "\n\t pb avec pièce située à l'Ouest";
					}
				}

				if (this.getPieceAdj(i, j, 'S') != null) 
				{
					if (this.getPiece(i, j).getOuverture('S') != this.getPieceAdj(i, j, 'S').getOuverture('N')) 
					{
						estOK = false;
						result += "\n\t pb avec pièce située au Sud";
					}
				}

				if (this.getPieceAdj(i, j, 'E') != null) 
				{
					if (this.getPiece(i, j).getOuverture('E') != this.getPieceAdj(i, j, 'E').getOuverture('O')) 
					{
						estOK = false;
						result += "\n\t pb avec pièce située à l'Est";
					}
				}

				if (estOK)
					result += "\t OK \n";
				else
					result += "\n";
			}
			result += "\n";
		}

		return result;
	}

	private Position rechercherPosition(Piece p) 
	{
		for (int i = 0; i < this.tabPiece.length; i++) 
		{
			for (int j = 0; j < this.tabPiece[0].length; j++) 
			{
				if (this.tabPiece[i][j] == p) 
				{
					return new Position(i, j);
				}
			}
		}

		return null;
	}

	private Position getPosPortailBleu()
	{
		for (int i = 0; i < this.tabPiece.length; i++) 
		{
			for (int j = 0; j < this.tabPiece[0].length; j++) 
			{
				if (this.tabPiece[i][j] != null && this.tabPiece[i][j].getPortailBleu()) 
				{
					return new Position(i, j);
				}
			}
		}

		return null;
	}

	private Position getPosPortailOrange()
	{
		for (int i = 0; i < this.tabPiece.length; i++) 
		{
			for (int j = 0; j < this.tabPiece[0].length; j++) 
			{
				if (this.tabPiece[i][j] != null && this.tabPiece[i][j].getPortailOrange()) 
				{
					return new Position(i, j);
				}
			}
		}

		return null;
	}

	public void deplacer(char dir) 
	{
		Position posHeros;
		int      lig,       col;
		int      nouvelLig, nouvelCol;

		posHeros = rechercherPosition(this.pieceHeros);

		lig = posHeros.getLig();
		col = posHeros.getCol();

		nouvelLig = nouvelCol = -1;

		switch (dir) {
			case 'n':
				if (this.orientationHeros == 'n') 
				{
					if (   this.getPieceAdj(lig, col, 'N') != null
					    && this.getPiece(lig, col).getOuverture('N')
					    && this.getPieceAdj(lig, col, 'N').getOuverture('S')) 
					{
						nouvelLig = lig - 1;
						nouvelCol = col;
						this.cptMvt++;
					}
				} 
				else 
				{
					this.orientationHeros = 'n';
				}

				break;

			case 'o':
				if (this.orientationHeros == 'o') 
				{
					if (   this.getPieceAdj(lig, col, 'O') != null
					    && this.getPiece(lig, col).getOuverture('O')
					    && this.getPieceAdj(lig, col, 'O').getOuverture('E')) 
					{
						nouvelLig = lig;
						nouvelCol = col - 1;
						this.cptMvt++;
					}
				} 
				else 
				{
					this.orientationHeros = 'o';
				}
				break;

			case 's':
				if (this.orientationHeros == 's') 
				{
					if (   this.getPieceAdj(lig, col, 'S') != null
					    && this.getPiece(lig, col).getOuverture('S')
					    && this.getPieceAdj(lig, col, 'S').getOuverture('N')) 
					{
						nouvelLig = lig + 1;
						nouvelCol = col;
						this.cptMvt++;
					}
				}
				else
				{
					this.orientationHeros = 's';
				}
				break;

			case 'e':
				if (this.orientationHeros == 'e') 
				{
					if (   this.getPieceAdj(lig, col, 'E') != null
					    && this.getPiece(lig, col).getOuverture('E')
					    && this.getPieceAdj(lig, col, 'E').getOuverture('O')) 
					{
						nouvelLig = lig;
						nouvelCol = col + 1;
						this.cptMvt++;
					}
				}
				else
				{
					this.orientationHeros = 'e';
				}
				break;
		}

		if (!(nouvelLig == -1 || nouvelCol == -1))
		{
			this.pieceHeros = this.tabPiece[nouvelLig][nouvelCol];

			if(this.pieceHeros.getCle()) 
			{   
				this.verifCle();
			}

			if(this.pieceHeros.getCoffre()) 
			{
				this.verifCoffre();
			}
		}
	}

	private void verifCle()
	{
		// heros sur la case cle;
		// 1. coffre est ferme
		// 2. heros n'a pas la cle
		if(!this.estCoffreOuvert && !this.aCle)
		{
			this.aCle = true;
		}
	}

	private void verifCoffre()
	{
		// heros sur la case coffre :
		// 1. coffre est ferme
		// 2. heros a la cle
		if(!this.estCoffreOuvert && this.aCle)
		{
			this.estCoffreOuvert = true;
			this.aCle            = false;
		}
	}

	public void teleporter()
	{
		if (this.pieceHeros.getPortailBleu())
		{
			this.pieceHeros = this.tabPiece[getPosPortailOrange().getLig()][getPosPortailOrange().getCol()] ;
		}
		else if (this.pieceHeros.getPortailOrange())
		{
			this.pieceHeros = this.tabPiece[getPosPortailBleu().getLig()][getPosPortailBleu().getCol()] ;
		}
	}

	public boolean deplacerPiece(int ligne1, int colonne1, int ligne2, int colonne2) 
	{
		if (Dedale.estAdjacent(ligne1, colonne1, ligne2, colonne2)
		&&   this.getPiece(ligne2, colonne2) == null
		&&   this.getPiece(ligne1, colonne1) != this.pieceHeros
		&&	!this.getPiece(ligne1, colonne1).getArrivee()
		&&   this.getPiece(ligne1, colonne1).getValOuvertures() != 0) 
		{
			this.tabPiece[ligne2][colonne2] = this.tabPiece[ligne1][colonne1];
			this.tabPiece[ligne1][colonne1] = null;
			this.cptCase++;
			return true;
		}

		return false;
	}

	// Méthode permettant de comparer 2 positions et de dire si elles sont
	// adjacentes
	private static boolean estAdjacent(int ligne1, int colonne1, int ligne2, int colonne2) 
	{
		return ((ligne1 == ligne2 + 1 && colonne1 == colonne2)
			||  (ligne1 == ligne2 - 1 && colonne1 == colonne2)
			||  (ligne1 == ligne2	  && colonne1 == colonne2 + 1)
			||  (ligne1 == ligne2	  && colonne1 == colonne2 - 1));
	}
}