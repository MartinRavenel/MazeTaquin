# Maze Taquin

## Instructions pour lancer l'application

### Prérequis

1. Installer Java sur votre PC. Vous pouvez télécharger et installer Java à partir du site officiel : [https://www.java.com/fr/download/].

### Lancer l'application

#### Sur Linux

1. Ouvrez un terminal.
2. Naviguez jusqu'au répertoire contenant le fichier `MazeTaquin.sh`.
3. Exécutez la commande suivante :
   ```sh
   ./MazeTaquin.sh

#### Sur Windows

1. Ouvrez l'invite de commandes.
2. Naviguez jusqu'au répertoire contenant le fichier `MazeTaquin.bat`.
3. Exécutez la commande suivante :
	```cmd
	MazeTaquin.bat
	```