public class Conversion
{
	public static boolean[] entier2Tab(int valeur, int nbElt)
	{
		/*----------*/
        /* Donnees  */
        /*----------*/

		/* Variable */
		
		boolean[] tabBool;
		int cpt;

		/*--------------*/
        /* Instructions */
        /*--------------*/

		tabBool = new boolean[nbElt];
		cpt     = 0;
		while (cpt < nbElt)
		{
			tabBool[cpt] = ((valeur % 2) == 1);
			valeur /= 2;
			cpt ++;
		}

		return tabBool;
	}

	public static int tab2Entier(boolean[] tab)
	{
		/*----------*/
        /* Donnees  */
        /*---- -----*/

		/* Variable */
		
		int somme;

		/*--------------*/
        /* Instructions */
        /*--------------*/

		somme = 0;
		for (int ind = 0; ind < tab.length; ind++)
		{
			if(tab[ind])
			{
				somme += Math.pow(2,ind);
			}
		}
		
		return somme;
	}

	public static String enChaine(boolean[] tab)
	{
		/*----------*/
        /* Donnees  */
        /*----------*/
		
        /*Variables */

        String res;
        String bordure, elts, indices;
		
        /*--------------*/
        /* Instructions */
        /*--------------*/
		
        res     = "";
        bordure = elts = indices = "";

		for( int cpt = 0; cpt < tab.length; cpt++ )
		{
			bordure += "+-----";
			elts    += "|"   + String.format("%-5s", tab[cpt]);
			indices += "   " + String.format("%-3s", cpt);
		}
		bordure += "+";
		elts    += "|";
	
		res = bordure + "\n" + elts + "\n" + bordure + "\n" + indices + "\n";

		return res;
	}


	//Méthode ligne, créée pour la méthode Detail
	//Ligne prend en argument un dedale et un entier correspondant à la ligne
	//Ligne renvoie un tableau de Piece
	private static Piece[] ligne ( Dedale dedale, int lig )
	{
		Piece[] ligne = new Piece[dedale.getNbColonne()] ;

		for (int i = 0; i < dedale.getNbColonne(); i++)
			ligne[i] = dedale.getPiece(lig, i) ;
		
		return ligne ;
	}

	public static String grille ( Dedale dedale )
	{
		String result = "+" ;

		//Première ligne de la grille
		for (int i = 0; i < dedale.getNbColonne(); i++)
		{
			result += "----+" ;
		}
		result += "\n" ;

		//Ajoute une ligne de grille et une ligne de valeurs à chaque itération
		for (int i = 0; i < dedale.getNbLigne(); i++)
		{
			//Ajoute les lignes de valeurs
			result += "| " ;
			for (int j = 0; j < dedale.getNbColonne(); j++)
			{
				result += String.format("%2s", dedale.getPiece(i, j).getValOuvertures()) 
						+ " | " ;
			}
			result += "\n+" ;

			//Ajoute les lignes de grille
			for (int j = 0; j < dedale.getNbColonne(); j++)
			{
				result += "----+" ;
			}
			result += "\n" ;
		}

		return result ;
	}

	public static String detail ( Dedale dedale )
	{
		String result = "" ;
		Piece[] ligne = new Piece[dedale.getNbColonne()] ;

		for (int i = 0; i < dedale.getNbLigne(); i++)
		{
			result += "== Ligne  " + i + " =============================================================================\n" ;
			ligne = Conversion.ligne(dedale, i) ;
			for (int j = 0; j < ligne.length; j++)
			{
				result += ligne[j].toString() + "\n" ;
			}
		}
		result += "=========================================================================================" ;

		return result ;
	}
}

