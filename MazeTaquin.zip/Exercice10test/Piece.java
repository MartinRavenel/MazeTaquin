public class Piece
{
	// ATTRIBUTS
	private static String[] tabDir = new String[] {"Nord", "Ouest", "Sud", "Est"} ;
	
	private String nom ;

	private boolean[] informations ;

	// CONTSTUCTEURS
	public Piece (int valeur , String nom)
	{
		this.informations = Conversion.entier2Tab(valeur, 10) ;
		this.nom = nom ;
	}

	public Piece ( int valeur )
	{
		this(valeur, "") ;
	}

	// METHODES
	public int getValOuvertures () 
	{
		return Conversion.tab2Entier(this.informations) % 16 ;
	}

	public boolean getOuverture ( char dir )
	{
		boolean result ;

		switch (dir) 
		{
			case 'N' -> result = this.informations[0] ;
			case 'O' -> result = this.informations[1] ;
			case 'S' -> result = this.informations[2] ;
			case 'E' -> result = this.informations[3] ;
			default  -> result = false;
		}

		return result;

	}

	private int indiceDir ( char dir )
	{
		int indice;

		switch (dir) 
		{
			case 'N' -> indice =  0;
			case 'O' -> indice =  1;
			case 'S' -> indice =  2;
			case 'E' -> indice =  3;
			default  -> indice = -1;
		}

		return indice;
	}


	public boolean getDepart ()
	{
		return this.informations[4] ;
	}

	public boolean getArrivee ()
	{
		return this.informations[5] ;
	}

	public boolean getPortailBleu ()
	{
		return this.informations[6] ;
	}

	public boolean getPortailOrange ()
	{
		return this.informations[7] ;
	}

	public boolean getCoffre ()
	{
		return this.informations[8] ;
	}
	public boolean getCle()
	{
		return this.informations[9] ;
	}


	// ETAT
	public String toString ()
	{
		String res;
		
		res =   String.format("%2s", this.getValOuvertures()) 
			  + " ";

		if("".equals(this.nom))
		{
			res +=  String.format("%-14s", "");  
		}
		else
		{
			res +=  String.format("%-14s", "(" + this.nom + ")"); 
		}

		res += " ==> " ;

		for(int i = 0; i < tabDir.length; i++)
		{
			res +=   Piece.tabDir     [i]                      + "(" 
				   + this.indiceDir(Piece.tabDir[i].charAt(0)) + ") :" 
			       + this.informations[i]                      + "\t";
		}

		res += "\n\tDépart : " + this.informations[4] + "\tArrivée : " + this.informations[5] ;

		return res;
	}
}