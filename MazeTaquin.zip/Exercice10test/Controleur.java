import ihmgui.FrameGrille;
import ihmgui.Controle;

public class Controleur extends Controle
{
	private Dedale metier;
	private FrameGrille frame;

	public Controleur() 
	{
		this.metier = new Dedale();
		this.frame = new FrameGrille(this);

		frame.setSize(1_000, 600);
		frame.setLocation(100, 100);
		frame.setTitle("Dedale");
		frame.setVisible(true);
	}

	public String setBouton(int numBtn) 
	{
		String lib;

		switch (numBtn) 
		{
			case 0:
				lib = "Niveau Suivant";
				break;
			case 1:
				lib = "Niveau Précédent";
				break;
			case 2:
				lib = "Réinitialiser";
				break;
			default:
				lib = null; // cette dernière ligne est importante, elle met fin à la contruction des boutons
		}

		return lib;
	}

	public void bouton(int action) 
	{
		if (action == 0) 
		{
			if (metier.niveaux('S'))
				frame.majIHM();
		}
		if (action == 1) 
		{
			if (metier.niveaux('P'))
				frame.majIHM();
		}
		if (action == 2) 
		{
			if (metier.niveaux('R'))
				frame.majIHM();
		}
		if (action == 3) 
		{
			if (metier.niveaux(' '))
				frame.majIHM();
		}
	}

	public int setLargeurLabel()
	{
		return 125;
	}

	public String setLabel(int numLbl) 
	{
		String lib;

		switch (numLbl) 
		{
			case 0:
				lib = "Niveau : ";
				break;
			case 1:
				lib = "Difficultée : ";
				break;
			case 2:
				lib = "";
				break;
			case 3:
				lib = "[SHIFT]   ";
				break;
			case 4:
				lib = "";
				break;
			case 5:
				lib = "NB mvt : ";
				break;
			case 6:
				lib = "NB case : ";
				break;
			default:
				lib = null; // cette dernière ligne est importante, elle met fin à la contruction des labels
		}

		return lib;
	}

	public String setTextLabel(int numLbl) 
	{
		String lib;

		switch (numLbl) 
		{
			case 0:
				lib = ""+metier.getNiveau();
				break;
			case 1:
				lib = metier.getDifficulte();
				break;
			case 2:
				lib = "";
				break;
			case 3:
				lib = "pour se téléporter";
				break;
			case 4:
				lib = "";
				break;
			case 5:
				lib = ""+metier.getCptMvt();
				break;
			case 6:
				lib = ""+metier.getCptCase();
				break;
			default:
				lib = null;
		}

		return lib;
	}

	public int setNbLigne() 
	{
		return this.metier.getNbLigne();
	}

	public int setNbColonne() 
	{
		return this.metier.getNbColonne();
	}

	public int setLargeurImg() 
	{
		return 100;
	}


	public String setFondGrille() 
	{
		return "./images/fond.png";
	}

	public String setImage(int ligne, int colonne, int couche) 
	{
		String rep = "./images/";
		String sImage = null;

		if (couche == 0) 
		{
			if (metier.getPiece(ligne, colonne) != null) 
			{
				sImage = rep + "P" + String.format("%02d", metier.getPiece(ligne, colonne).getValOuvertures()) + ".png";
			}
			else 
			{
				sImage = rep + "lave.png";
			}
		}

		if (couche == 2) 
		{
			char symb = metier.getSymboleHeros(ligne, colonne);
			if (symb != ' ')
			{
				sImage = rep + "dw_" + symb ;
				if (metier.getACle())
					sImage += "_c" ;
				sImage += ".png" ;
			}
			else
				sImage = "";
		}

		if (couche == 1) 
		{
			sImage = "";
			if (metier.getPiece(ligne, colonne) != null && metier.getPiece(ligne, colonne).getDepart()) 
			{
				sImage = rep + "depart.png";
			}

			if (metier.getPiece(ligne, colonne) != null && metier.getPiece(ligne, colonne).getArrivee()) 
			{
				if (!metier.getEstCoffreOuvert())
					sImage = rep + "arrivee_f.png";
				else
					sImage = rep + "arrivee.png";
			}

			if (metier.getPiece(ligne, colonne) != null && metier.getPiece(ligne, colonne).getPortailBleu()) 
			{
				sImage = rep + "portail_bleu.png";
			}

			if (metier.getPiece(ligne, colonne) != null && metier.getPiece(ligne, colonne).getPortailOrange()) 
			{
				sImage = rep + "portail_orange.png";
			}

			if (metier.getPiece(ligne, colonne) != null && metier.getPiece(ligne, colonne).getCoffre()) 
			{
				if (!metier.getEstCoffreOuvert())
					sImage = rep + "coffre_ferme.png";
				else
				{
					sImage = rep + "coffre_ouvert.png";
				}
			}

			if (metier.getPiece(ligne, colonne) != null && metier.getPiece(ligne, colonne).getCle() && !metier.getACle()) 
			{
				if (!metier.getEstCoffreOuvert())
					sImage = rep + "cle.png";	
			}

		}

		return sImage;
	}

	public void jouer(String touche) 
	{
		if (touche.equals("FL-H"))
			metier.deplacer('n');

		if (touche.equals("FL-G"))
			metier.deplacer('o');

		if (touche.equals("FL-B"))
			metier.deplacer('s');

		if (touche.equals("FL-D"))
			metier.deplacer('e');

		if (touche.equals("SH-"))
			metier.teleporter(); 

		frame.majIHM();
	}

	public void glisser(int ligne1, int colonne1, int ligne2, int colonne2) 
	{

		if (!metier.deplacerPiece(ligne1, colonne1, ligne2, colonne2)) 
		{
			System.out.println("Déplacement impossible !!!!!!");
		} 

		frame.majIHM();
	}

	public static void main(String[] a) 
	{
		new Controleur();
	}

}